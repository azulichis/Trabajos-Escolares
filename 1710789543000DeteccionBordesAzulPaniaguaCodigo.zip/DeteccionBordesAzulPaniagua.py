import cv2
import tkinter as tk
from tkinter import filedialog, font, ttk, messagebox
from PIL import Image, ImageTk
import numpy 
from scipy import misc
from scipy import ndimage
import matplotlib.pyplot as plt
from scipy.ndimage import convolve

class Clic(tk.Button):
    def __init__(self, master=None, **kwargs):
        tk.Button.__init__(self, master=master, **kwargs)
        self.default_bg = self["bg"]
        self.bind("<Enter>", self.on_enter)
        self.bind("<Leave>", self.on_leave)

    def on_enter(self, event):
        self.configure(bg="#FFC0CB", fg="#FFFFFF")  
    def on_leave(self, event):
        self.configure(bg="white", fg="#77B9D7")  

class ImageProcessorApp:
    image = None
    file_path = None
    duplicado = False
    primera_vez = True
    seleccionado = 0
    promedio = 0

    def __init__(self,root):
        self.root = root
        self.root.title("Procesador de Imágenes")
        self.root.geometry("800x600")
        
        self.root.config(bg="#c8a2c8")
        
        # Crear una etiqueta * investigar el constructor, widget, tmb una forma de agregar widgets
        self.etiqueta = tk.Label(root, text="Procesamiento digital de imágenes", bg="#c8a2c8", fg="white", font=("Impact", 14))
        self.etiqueta.pack(pady=15) 
        
        self.load_button = Clic(root, text="Cargar Imagen", fg="#77B9D7", font=("Impact", 14), command=self.load_image)
        self.load_button.pack(side=tk.TOP, padx=5, pady=5, anchor = "center")
        
        frame_rgb = tk.Frame(root, bg="#c8a2c8")
        frame_rgb.pack()
        
        self.red = tk.Label(frame_rgb, text="Red: ", bg="#c8a2c8", fg="white", font=("Impact", 14))
        self.red.pack(side=tk.LEFT, padx=5, pady=5, anchor="center")
        
        self.green = tk.Label(frame_rgb, text="Green: ", bg="#c8a2c8", fg="white", font=("Impact", 14))
        self.green.pack(side=tk.LEFT, padx=5, pady=5, anchor="center")
        
        self.blue = tk.Label(frame_rgb, text="Blue: ", bg="#c8a2c8", fg="white", font=("Impact", 14))
        self.blue.pack(side=tk.LEFT, padx=5, pady=5, anchor="center")
        
        frameButton = tk.Frame(root, bg="#c8a2c8")
        frameButton.pack(side="right", fill="y") 

        self.grayscale_button = Clic(frameButton, text="Escala de grises", fg="#77B9D7", font=("Impact", 14), command=self.grayscale_image)
        self.grayscale_button.pack(fill="x")

        self.bin1_button = Clic(frameButton, text="Binarización 1", fg="#77B9D7", font=("Impact", 14), command=self.binarizar_image)
        self.bin1_button.pack(fill="x")

        self.bin2_button = Clic(frameButton, text="Binarización 2", fg="#77B9D7", font=("Impact", 14), command=self.binarizar_dinamico_image)
        self.bin2_button.pack(fill="x")

        self.multi_button = Clic(frameButton, text="Negativo", fg="#77B9D7", font=("Impact", 14), command=self.negativo_image)
        self.multi_button.pack(fill="x")

        self.smooth_button = Clic(frameButton, text="Suavizado", fg="#77B9D7", font=("Impact", 14), command=self.smooth_image)
        self.smooth_button.pack(fill="x")
        
        self.smoothP_button = Clic(frameButton, text="Suavizado2", fg="#77B9D7", font=("Impact", 14), command=self.smooth2_image)
        self.smoothP_button.pack(fill="x")
        
        self.nolineal_button = Clic(frameButton, text="No lineal", fg="#77B9D7", font=("Impact", 14), command=self.nolineal_image)
        self.nolineal_button.pack(fill="x")
        
        self.prewitt_button = Clic(frameButton, text="Prewitt", fg="#77B9D7", font=("Impact", 14), command=self.prewitt_image)
        self.prewitt_button.pack(fill="x")
        
        self.roberts_button = Clic(frameButton, text="Roberts", fg="#77B9D7", font=("Impact", 14), command=self.roberts_image)
        self.roberts_button.pack(fill="x")
        
        self.sobel_button = Clic(frameButton, text="Sobel", fg="#77B9D7", font=("Impact", 14), command=self.sobel_image)
        self.sobel_button.pack(fill="x")
        
        self.canny_button = Clic(frameButton, text="Canny", fg="#77B9D7", font=("Impact", 14), command=self.canny_image)
        self.canny_button.pack(fill="x")
        
        self.canny2_button = Clic(frameButton, text="Canny2", fg="#77B9D7", font=("Impact", 14), command=self.canny2)
        self.canny2_button.pack(fill="x")
        
        
        self.barra_progreso = ttk.Progressbar(root, orient="horizontal", length=800, mode="determinate")
        self.barra_progreso.pack(fill="x", padx=10, pady=(0, 10))
        
        
        # Frame para contener el Canvas y las barras de desplazamiento
        frame = tk.Frame(root, bg="#c8a2c8")
        frame.pack(side="left", fill="both", expand=True)
        # Barra de desplazamiento vertical
        y_scrollbar = tk.Scrollbar(frame, orient="vertical")
        y_scrollbar.pack(side="right", fill="y")
        # Barra de desplazamiento horizontal
        x_scrollbar = tk.Scrollbar(frame, orient="horizontal")
        x_scrollbar.pack(side="bottom", fill="x")
        
        # Canvas para mostrar la imagen
        self.canvas = tk.Canvas(frame, bg="#c8a2c8", yscrollcommand=y_scrollbar.set,
        xscrollcommand=x_scrollbar.set)
        self.canvas.pack(expand=True,fill="both", side="left")
        self.canvas.bind("<Motion>", self.on_mouse_move)
        
        frame_botones = tk.Frame(root, bg="#c8a2c8")
        frame_botones.pack(side="left", padx=10)
        
        self.pasar_imagen_button = Clic(frame_botones, text="Pasar imagen ->", fg="#77B9D7", font=("Impact", 14), command=self.duplicado_image)
        self.pasar_imagen_button.pack()
        
        self.actual = tk.Label(frame_botones, text="Ninguna imagen seleccionada", bg="#c8a2c8", fg="white", font=("Impact", 14))
        self.actual.pack(pady=5)
        
        self.imagen_a = Clic(frame_botones, text="Imagen A", fg="#77B9D7", font=("Impact", 14), command=self.seleccion1)
        self.imagen_a.pack(pady=5)
        
        self.imagen_b = Clic(frame_botones, text="Imagen B", fg="#77B9D7", font=("Impact", 14), command=self.seleccion2)
        self.imagen_b.pack(pady=5)
        
        # Configurar las barras de desplazamiento
        y_scrollbar.config(command=self.canvas.yview)
        x_scrollbar.config(command=self.canvas.xview)
        self.canvas.config(scrollregion=self.canvas.bbox("all")) 
        
        # Frame para contener el Canvas y las barras de desplazamiento
        frame_dos = tk.Frame(root, bg="#c8a2c8")
        frame_dos.pack(side="left", fill="both", expand=True)
        # Barra de desplazamiento vertical
        y_scrollbar_dos = tk.Scrollbar(frame_dos, orient="vertical")
        y_scrollbar_dos.pack(side="right", fill="y")
        # Barra de desplazamiento horizontal
        x_scrollbar_dos = tk.Scrollbar(frame_dos, orient="horizontal")
        x_scrollbar_dos.pack(side="bottom", fill="x")
        
        # Canvas para mostrar la imagen
        self.canvas_dos = tk.Canvas(frame_dos, bg="#c8a2c8", yscrollcommand=y_scrollbar_dos.set,
        xscrollcommand=x_scrollbar_dos.set)
        self.canvas_dos.pack(expand=True,fill="both", side="left")
        self.canvas_dos.bind("<Motion>", self.on_mouse_move)
        
        # Configurar las barras de desplazamiento
        y_scrollbar_dos.config(command=self.canvas_dos.yview)
        x_scrollbar_dos.config(command=self.canvas_dos.xview)
        self.canvas_dos.config(scrollregion=self.canvas_dos.bbox("all")) 
    
        
    def load_image(self):
        file_path = filedialog.askopenfilename(
        title="Seleccionar Imagen", filetypes=[("Archivos PNG",
        "*.png"), ("Archivos JPG", "*.jpg")])
        if self.primera_vez == False:
            self.canvas.delete("all")
            self.canvas_dos.delete("all")
            self.duplicado = False
            self.seleccionado = 0
        if file_path:
            self.image_path = file_path
            self.image = cv2.imread(file_path)
            self.display_image()
            self.barra_progreso["maximum"] = len(self.image)
        self.primera_vez = False
        self.image1 = self.image.copy()
        self.image = self.image1

    def display_image(self):
        if self.image is not None:
            if self.seleccionado == 2:
                img_rgb = cv2.cvtColor(self.image2, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(img_rgb)
                img_tk = ImageTk.PhotoImage(img)
                self.canvas_dos.create_image(0, 0, anchor=tk.NW, image=img_tk)
                self.canvas_dos.image = img_tk
                self.canvas_dos.config(scrollregion = self.canvas_dos.bbox("all"))
            elif self.seleccionado == 0:
                img_rgb = cv2.cvtColor(self.image, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(img_rgb)
                img_tk = ImageTk.PhotoImage(img)
                self.canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
                self.canvas.image = img_tk
                self.canvas.config(scrollregion = self.canvas.bbox("all"))
                self.seleccionado = 1
            elif self.duplicado == False or self.seleccionado == 1:
                img_rgb = cv2.cvtColor(self.image1, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(img_rgb)
                img_tk = ImageTk.PhotoImage(img)
                self.canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
                self.canvas.image = img_tk
                self.canvas.config(scrollregion = self.canvas.bbox("all"))
        if self.seleccionado == 0:
            self.actual.config(text="Ninguna imagen seleccionada")
        if self.seleccionado == 1:
            self.actual.config(text="Imagen A seleccionada")
        if self.seleccionado == 2:
            self.actual.config(text="Imagen B seleccionada")
                
    def seleccion1(self):
        if self.image is not None:
            self.seleccionado = 1
            self.actual.config(text="Imagen A seleccionada")
            self.image = self.image1
        else:
            messagebox.showinfo("Alerta", "No hay ninguna imagen en el canvas 1")
        
    def seleccion2(self):
        if self.duplicado is not False:
            self.seleccionado = 2
            self.actual.config(text="Imagen B seleccionada")
            self.image = self.image2
        else:
            messagebox.showinfo("Alerta", "No hay ninguna imagen en el canvas 2")
            
    def duplicado_image(self):
        if self.image is not None:
            self.image2 = self.image1.copy()
            img_rgb = cv2.cvtColor(self.image2, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(img_rgb)
            img_tk = ImageTk.PhotoImage(img)
            self.canvas_dos.create_image(0, 0, anchor=tk.NW, image=img_tk)
            self.canvas_dos.image = img_tk
            self.canvas_dos.config(scrollregion=self.canvas_dos.bbox("all"))
            self.duplicado = True
        else:
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            
    def on_mouse_move(self, event):
        if self.image is None: return
        # Obtener (x, y) del puntero con respecto al Canvas
        x_canvas = event.x
        y_canvas = event.y
        # Imprimir las coordenadas con respecto al Canvas
        if y_canvas < len(self.image) and x_canvas < len(self.image[0]):
            print(f"Coordenadas en Canvas: ({x_canvas}, {y_canvas})")
            self.red.config(text="R: " + str(self.image[y_canvas][x_canvas][2]))
            self.green.config(text="G: " + str(self.image[y_canvas][x_canvas][1]))
            self.blue.config(text="B: " + str(self.image[y_canvas][x_canvas][0]))
            
    def copiar(self):
        if self.seleccionado == 1:
            return self.image1
        if self.seleccionado == 2:
            return self.image2 
            
    def en_cual_imagen(self, cambio):
        if self.seleccionado == 1:
            self.image1 = cambio.copy()
        if self.seleccionado == 2:
            self.image2 = cambio.copy()
        
            
    def grayscale_image(self):
        if self.image is not None:
        # Aplicar algún filtro, por ejemplo escala de grises
            self.barra_progreso["value"] = 0
            self.image = self.copiar().copy()
            print(type(self.image))
            print(type(self.image[0][0][0]))
            print(self.image.ndim)
            print("Filas",len(self.image))
            print("Columnas",len(self.image[0]))
            print(self.image.shape)
            filas, columnas, canales = self.image.shape
            new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)
            for f in range(filas):
                for c in range(columnas):
                    self.promedio = numpy.mean(self.image[f,c])
                    new_image[f,c] = [numpy.uint8(self.promedio), numpy.uint8(self.promedio), numpy.uint8(self.promedio)]
                if f%50==0 or f==filas-1:    
                    self.barra_progreso["value"] = f
                    root.update()
            self.en_cual_imagen(new_image)
            self.display_image()
            print("Filtro aplicado en lienzo: ", self.seleccionado)
        else:
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            
    def binarizar_image(self):
        if self.image is not None:
        # Aplicar algún filtro, por ejemplo escala de grises
            self.barra_progreso["value"] = 0
            self.image = self.copiar().copy()
            print(type(self.image))
            print(type(self.image[0][0][0]))
            print(self.image.ndim)
            print("Filas",len(self.image))
            print("Columnas",len(self.image[0]))
            print(self.image.shape)
            filas, columnas, canales = self.image.shape
            new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)
            for f in range(filas):
                for c in range(columnas):
                    pro = numpy.mean(self.image[f,c])
                    if pro >= 128:
                        new_image[f,c] = [255,255,255]
                    else:
                        new_image[f,c] = [0,0,0]
                if f%50==0 or f==filas-1:    
                    self.barra_progreso["value"] = f
                    root.update()
            self.en_cual_imagen(new_image)
            self.display_image()
            print("Filtro aplicado en lienzo: ", self.seleccionado)
        else:
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            
    def binarizar_dinamico_image(self):
        if self.image is not None:
        # Aplicar algún filtro, por ejemplo escala de grises
            self.image = self.copiar().copy()
            print(type(self.image))
            print(type(self.image[0][0][0]))
            print(self.image.ndim)
            print("Filas",len(self.image))
            print("Columnas",len(self.image[0]))
            print(self.image.shape)
            self.barra_progreso["value"] = 0
            filas, columnas, canales = self.image.shape
            new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)
            bin = 0
            pixeles = 0
            for f in range(filas):
                for c in range(columnas):
                    bin += numpy.mean(self.image[f,c])
            prom = bin // (filas*columnas)
            for f in range(filas):
                for c in range(columnas):
                    pro = numpy.mean(self.image[f,c])
                    if pro >= prom:
                        new_image[f,c] = [255,255,255]
                    else:
                        new_image[f,c] = [0,0,0]
                if f%50==0 or f==filas-1:    
                    self.barra_progreso["value"] = f
                    root.update()
            print(prom)
            self.en_cual_imagen(new_image)
            self.display_image()
            print("Filtro aplicado en lienzo: ", self.seleccionado)
        else: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            
    def negativo_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)
        for f in range(filas):
            for c in range(columnas):
                new_image[f,c] = 255 - self.image[f,c] 
            if f%50==0 or f==filas-1:    
                self.barra_progreso["value"] = f
                root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
            
    def smooth_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)
        for f in range(filas):
            for c in range(columnas):
                f1, f2 = f-1, f+1
                c1, c2 = c-1, c+1
                if f1<0: f1 = 0
                if c1<0: c1 = 0
                if f2>filas-1: f2 = filas-1
                if c2>columnas-1: c2 = columnas-1
                region = self.image[f1:f2+1,c1:c2+1]
                valor  = region.mean()
                new_image[f,c] = [numpy.uint8(valor), numpy.uint8(valor), numpy.uint8(valor)]
            if f%50==0 or f==filas-1:    
                self.barra_progreso["value"] = f
                root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)
        
    def smooth2_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        mask = [[ 0, 1, 0], 
		        [ 1, 3, 1], 
		        [ 0, 1, 0] ]
        mask = numpy.ndarray(shape =(3,3), dtype=int, buffer=numpy.array(mask, dtype=int))

        region = [[ 100, 10, 100], 
		          [  10, 10,  10], 
		          [ 100, 10, 100] ]
        region = numpy.ndarray(shape =(3,3), dtype=int, buffer=numpy.array(region, dtype=int))
        print(mask)
        print(region)
        print(mask.sum())
        print(mask.max())
        print(mask.min())
        result = mask*region
        print(result)

        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)
        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                f1, f2 = f-1, f+1
                c1, c2 = c-1, c+1
                region = self.image[f1:f2+1,c1:c2+1,0]
                # Resolver los bordes en el proyecto final
                result = mask*region
                valor = result.sum() / mask.sum()
                new_image[f,c] = [numpy.uint8(valor), numpy.uint8(valor), numpy.uint8(valor)]
                if c==10 and f==10:
                    print("mask\n",mask)
                    print("region\n",region)
                    print("result\n",result)
                    print("mask.sum():", mask.sum())
                    print("result.sum():", result.sum())
                    print("Valor:", valor)                
            if f%50==0 or f==filas-2:    
                self.barra_progreso["value"] = f
                root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)
        
    def nolineal_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        mask = [ [ 1, 1, 1],
                [ 1, -2, 1],
                [-1, -1, -1] ]
        mask = numpy.ndarray(shape =(3,3), dtype=int, buffer=numpy.array(mask, dtype=int))
        
        region = [[100,10,100],
                  [10,10,10],
                  [100,10,100]]
        region = numpy.ndarray(shape = (3,3), dtype=int, buffer=numpy.array(region,dtype=int))
        print(mask)
        print(region)
        print(mask.sum())
        print(mask.max())
        print(mask.min())
        result = mask*region
        print(result)
        print(result.sum())
        print(result.max())
        print(result.min())
        
        self.image = self.copiar().copy()
        filas,columnas,canales =self.image.shape
        mag_image = numpy.ndarray(shape=(filas,columnas), dtype=int)
        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                f1,f2 = f-1, f+1
                c1,c2 = c-1, c+1
                region = self.image[f1:f2+1,c1:c2+1,0]
                multi = mask*region
                suma = multi.sum()
                mag_image[f,c] = suma
        print(mag_image.max())
        print(mag_image.min())
        _max = mag_image.max()
        _min = mag_image.min()
        
        mag_image = (mag_image - _min)*255 / (_max - _min)
        
        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)
        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                valor = mag_image[f,c]
                new_image[f,c] = [numpy.uint8(valor), numpy.uint(valor), numpy.uint(valor)]
            if f%50==0 or f==filas-2:    
                self.barra_progreso["value"] = f
                root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)
            
    def prewitt_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        horizontal = [ [ -1, 0, 1],
                [ -1, 0, 1],
                [-1, 0, 1] ]
        horizontal = numpy.ndarray(shape =(3,3), dtype=int, buffer=numpy.array(horizontal, dtype=int))
        
        vertical = [[1, 1, 1],
                  [0,0,0],
                  [-1,-1,-1]]
        vertical = numpy.ndarray(shape = (3,3), dtype=int, buffer=numpy.array(vertical,dtype=int))
        new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)

        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                f1,f2 = f-1, f+1
                c1,c2 = c-1, c+1
                region = self.image[f1:f2+1,c1:c2+1,0]
                enx = numpy.sum(horizontal*region)
                eny = numpy.sum(vertical*region)
                valor = numpy.sqrt((enx ** 2) + (eny ** 2))
                new_image[f, c] = [numpy.uint8(valor), numpy.uint8(valor), numpy.uint(valor)]
            if f%50==0 or f==filas-2:    
                self.barra_progreso["value"] = f
                root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)
    
    def roberts_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        horizontal = [ [ -1, 0, 0],
                [ 0, 1, 0],
                [0, 0, 0] ]
        horizontal = numpy.ndarray(shape =(3,3), dtype=int, buffer=numpy.array(horizontal, dtype=int))
        
        vertical = [[0, 0, -1],
                  [0,1,0],
                  [0,0,0]]
        vertical = numpy.ndarray(shape = (3,3), dtype=int, buffer=numpy.array(vertical,dtype=int))
        new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)

        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                f1,f2 = f-1, f+1
                c1,c2 = c-1, c+1
                region = self.image[f1:f2+1,c1:c2+1,0]
                enx = numpy.sum(horizontal*region)
                eny = numpy.sum(vertical*region)
                valor = numpy.sqrt((enx ** 2) + (eny ** 2))
                new_image[f, c] = [numpy.uint8(valor), numpy.uint8(valor), numpy.uint(valor)]
            if f%50==0 or f==filas-2:    
                self.barra_progreso["value"] = f
                root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)
            
    def sobel_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        horizontal = [ [ -1, 0, 1],
                [ -2, 0, 2],
                [-1, 0, 1] ]
        horizontal = numpy.ndarray(shape =(3,3), dtype=int, buffer=numpy.array(horizontal, dtype=int))
        
        vertical = [[-1, -2, -1],
                  [0,0,0],
                  [1,2,1]]
        vertical = numpy.ndarray(shape = (3,3), dtype=int, buffer=numpy.array(vertical,dtype=int))
        new_image = numpy.ndarray(shape=self.image.shape, dtype=numpy.uint8)

        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                f1,f2 = f-1, f+1
                c1,c2 = c-1, c+1
                region = self.image[f1:f2+1,c1:c2+1,0]
                enx = numpy.sum(horizontal*region)
                eny = numpy.sum(vertical*region)
                valor = numpy.sqrt((enx ** 2) + (eny ** 2))
                new_image[f, c] = [numpy.uint8(valor), numpy.uint8(valor), numpy.uint(valor)]
            if f%50==0 or f==filas-2:    
                self.barra_progreso["value"] = f
                root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)
        
    def sobel_para_canny_image(self, imagensobel):
        filas, columnas, canales = imagensobel.shape
        horizontal = [ [ -1, 0, 1],
                [ -2, 0, 2],
                [-1, 0, 1] ]
        horizontal = numpy.ndarray(shape =(3,3), dtype=int, buffer=numpy.array(horizontal, dtype=int))
        
        vertical = [[-1, -2, -1],
                  [0,0,0],
                  [1,2,1]]
        vertical = numpy.ndarray(shape = (3,3), dtype=int, buffer=numpy.array(vertical,dtype=int))
        new_image = numpy.ndarray(shape=imagensobel.shape, dtype=numpy.uint8)
        
        alto, ancho = imagensobel.shape[:2]
        magnitud = numpy.zeros((alto, ancho), dtype=numpy.uint8)
        angulo = numpy.zeros((alto, ancho), dtype=numpy.uint8)

        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                f1,f2 = f-1, f+1
                c1,c2 = c-1, c+1
                region = imagensobel[f1:f2+1,c1:c2+1,0]
                enx = numpy.sum(horizontal*region)
                eny = numpy.sum(vertical*region)
                valor = numpy.sqrt((enx ** 2) + (eny ** 2))
                magnitud[f, c] = numpy.sqrt(enx**2 + eny**2)
                angulo[f, c] = numpy.degrees(numpy.arctan2(eny, enx))
                new_image[f, c] = [numpy.uint8(valor), numpy.uint8(valor), numpy.uint(valor)]
        return new_image, magnitud, angulo
       

    def canny_image(self):
        if self.image is None: 
            messagebox.showinfo("Alerta", "No hay ninguna imagen abierta")
            return
        self.barra_progreso["value"] = 0
        self.image = self.copiar().copy()
        filas, columnas, canales = self.image.shape
        nuevo, magnitudes, angulos = self.sobel_para_canny_image(self.image)
        new_image = numpy.ndarray(shape=nuevo.shape, dtype=numpy.uint8)
        
        umbral_alto = 120
        umbral_bajo = 90
        
        angulos = numpy.round(angulos / 45) * 45
        for f in range(1,filas-1):
            for c in range(1,columnas-1):
                gradiente_actual = magnitudes[f, c]
                direccion_actual = angulos[f,c]
                if direccion_actual == 0 or direccion_actual == 360 or direccion_actual == 180:
                    vecino1 = (f, c - 1)
                    vecino2 = (f, c + 1)
                elif direccion_actual == 45 or direccion_actual == 225:
                    vecino1 = (f + 1, c + 1)
                    vecino2 = (f - 1, c - 1)
                elif direccion_actual == 90 or direccion_actual == 270:
                    vecino1 = (f , c+1)
                    vecino2 = (f , c-1)
                elif direccion_actual == 135 or direccion_actual == 315:
                    vecino1 = (f - 1, c + 1)
                    vecino2 = (f + 1, c - 1)
                
                if (vecino1 is not None and vecino2 is not None and
                0 <= vecino1[0] < filas and 0 <= vecino1[1] < columnas and
                0 <= vecino2[0] < filas and 0 <= vecino2[1] < columnas):
                    
                    magnitud_vecino1 = magnitudes[vecino1]
                    magnitud_vecino2 = magnitudes[vecino2]
                    
                    if gradiente_actual > magnitud_vecino1 and gradiente_actual > magnitud_vecino2:
                        if gradiente_actual > umbral_alto:
                            new_image[f,c] = [255,255,255]
                        elif umbral_bajo < gradiente_actual < umbral_alto:
                            if magnitudes[f,c+1] > umbral_alto or magnitudes[f, c-1] > umbral_alto or magnitudes[f+1,c] > umbral_alto or magnitudes[f-1,c] > umbral_alto or magnitudes[f,c+1] > umbral_alto or magnitudes[f+1,c+1] > umbral_alto or magnitudes[f-1,c-1] > umbral_alto or magnitudes[f+1,c-1] > umbral_alto or magnitudes[f-1,c+1] > umbral_alto:
                                new_image[f, c] = nuevo[f,c]
                        else: new_image[f, c] = [0, 0, 0]
                    else:
                        new_image[f, c] = [0, 0, 0]
                        
            if f%50==0 or f==filas-2:    
                    self.barra_progreso["value"] = f
                    root.update()
        self.en_cual_imagen(new_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)
        
    def canny2(self):
        blurred_image = cv2.GaussianBlur(self.image, (5, 5), 0)
        canny_image = cv2.Canny(blurred_image, 100, 200)
        self.en_cual_imagen(canny_image)
        self.display_image()
        print("Filtro aplicado en lienzo: ", self.seleccionado)

root= tk.Tk()
app = ImageProcessorApp(root)
root.mainloop()