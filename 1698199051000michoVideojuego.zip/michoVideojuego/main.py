import pygame

from pygame import *

import sys

import random


init()

# Variables que serán usadas 
screen = display.set_mode((800,600))
myFont=font.SysFont('Calibri',40)
clicniv1 = Rect(300,300,220,50)
clicniv2 = Rect(300,400,220,50)
clicniv3 = Rect(300,500,220,50)
continuarbut = Rect(290,450,200,90)
continuarbut2= Rect(520,500,160,50)
menunivel2 = Rect(750,15,35,35)
niv2background = image.load('fondo_nivel2.jpg')
niv2background = transform.scale(niv2background, (800,600))
michoniv2 = image.load('michoL.png')
michoniv2 = transform.scale(michoniv2, (50,50))
display.set_caption('Finding Micho')
platform_image=image.load('barra.png').convert_alpha()
casitaniv2 = image.load('casita.png')
casitaniv2 = transform.scale(casitaniv2, (35,35))
nivcompletos = 0
game_over = False 




#NIVEL 1
class Game_object():
    def  __init__(self,display,imagefile,width,height,locationX,locationY):
        image = pygame.image.load(imagefile)
        self.image = pygame.transform.scale(image,(width,height))
        self.width = width
        self.height = height
        self.x = locationX
        self.y = locationY
        self.display = display
        self.Dinfo = pygame.display.Info()
       
    def show(self):
        self.display.blit(self.image,(self.x,self.y))

    def right(self,Hspeed):
        if (self.x+self.width+Hspeed) <= self.Dinfo.current_w:
            self.x += Hspeed

    def left(self,Hspeed):
        if(self.x - Hspeed) >= 0:
            self.x -= Hspeed

    def up(self,Vspeed):
        if(self.y - Vspeed) >= 0:
            self.y -= Vspeed

    def down(self,Vspeed):
        if (self.y + self.height + Vspeed) <= self.Dinfo.current_h:
            self.y += Vspeed

    def move(self,x,y):
        self.x += x
        self.y += y
    
    def check_on(self,Player):
        if ((Player.x + Player.width) >= self.x) and (Player.x <= (self.x + self.width)):
            return True
        return False 

class Vehicle(Game_object):
    def __init__(self,display,imagefile,width,height,locationX,locationY,Hspeed,direction):
       super().__init__(display,imagefile,width,height,locationX,locationY)
       self.direction = direction
       self.flip()

    def flip(self):
        if self.direction != -1:
            self.image = pygame.transform.flip(self.image,True,False)

class Car(Vehicle):
    def __init__(self,display,width,height,locationX,locationY,Hspeed,direction):
        super().__init__(display,"auto.png",width,height,locationX,locationY,Hspeed,direction)
       
class Bike(Vehicle):
    def __init__(self,display,width,height,locationX,locationY,Hspeed,direction):
        super().__init__(display,"motomami2.png",90,70,locationX,locationY,Hspeed,direction)
        
class Truck(Vehicle):
    def __init__(self,display,width,height,locationX,locationY,Hspeed,direction):
        super().__init__(display,"truck.png",width,90,locationX,locationY,Hspeed,direction)
        
class Path(Game_object):
    def __init__(self,display,imagefile,locationY,Hspeed,path_height):
        self.Dinfo = pygame.display.Info()
        self.width = int(self.Dinfo.current_w)
        self.height = path_height
        super().__init__(display,imagefile,self.width,self.height,0,locationY)
        self.direction = random.randint(0,1)
        if self.direction == 0:
            self.direction = -1
        self.Hspeed = Hspeed * self.direction
        if self.direction == -1:
            self.I = random.randint(50,150)
        else:
            self.I = self.width - random.randint(50,150)
        self.Objects = []

    def add_objects(self):
        r_num = random.randint(10,15)
        for _ in range(r_num):
            Object = self.add_object()
            Object.y = self.y + (self.height-Object.height)/2
            if self.direction == -1:
                Object.x = self.I
                self.I += Object.width + random.randint(int(self.Dinfo.current_w/8),int(self.Dinfo.current_w/4))
            else:
                Object.x = self.I - Object.width
                self.I -= Object.width + random.randint(int(self.Dinfo.current_w/8),int(self.Dinfo.current_w/4))
            self.Objects.append(Object)

    def traffic(self,Player):
        if self.direction == -1:
            for Object in self.Objects:
                if Object.x + Object.width < 0:
                    Object.x = self.I
                    self.I += Object.width + random.randint(int(self.Dinfo.current_w/8),int(self.Dinfo.current_w/4))
                else:
                    Object.move(self.Hspeed,0)
        else:
            for Object in self.Objects:
                if Object.x > self.width:
                    Object.x = self.I - Object.width
                    self.I -= random.randint(int(self.Dinfo.current_w/8),int(self.Dinfo.current_w/4))
                else:
                    Object.move(self.Hspeed,0)

    def on_objects(self,Player):
        if self.player_on_path(Player):
            for Object in self.Objects:
                if Object.check_on(Player):
                    return True
        return False

    def player_on_path(self,Player):
        if Player.y <= (self.y + self.height) and (Player.y + Player.height) >= self.y:
            return True
        return False

    def show(self):
        super().show()
        for Object in self.Objects:
            Object.show()


class Car_path(Path):
    CAR = 0
    TRUCK = 1
    BIKE = 2
    def __init__(self,display,locationY,Hspeed,path_height):
        super().__init__(display,"road2.png",locationY,Hspeed,path_height)
        
    def add_object(self):
        vehicleType = random.randint(0,2)
        if vehicleType == self.CAR:
            Object = Car(self.display,int(self.width/6),self.height,0,0, self.Hspeed,self.direction)
        elif vehicleType == self.TRUCK:
            Object = Truck(self.display,int(self.width/5),self.height,0,0,self.Hspeed,self.direction)
        else:
            Object = Bike(self.display,int(self.width/8),self.height,0,0,self.Hspeed,self.direction)
        return Object

    def failed(self,Player):
        return self.on_objects(Player)
    
class Paths():
    def __init__(self,display,locationY,Player,path_height):
        self.display = display
        self.Dinfo = pygame.display.Info()
        self.y = locationY
        self.paths = []
        self.path_height = path_height
        self.build()
        self.height = self.paths[0].height * len(self.paths)

    def build(self):
        pass
        
    def check_on(self,Player):
        if Player.y <= (self.y + self.height) and (Player.y + Player.height) >= self.y:
            return True
        return False

    def show(self):
        for path in self.paths:
            path.show()

    def failed(self,Player):
        for path in self.paths:
            if path.failed(Player):
                return True
        return False

    def traffic(self,Player):
        for path in self.paths:
            path.traffic(Player)


class Life(Game_object):
    def __init__(self,display,width,height,locationX,locationY):
        super().__init__(display,"life.png",30,25,locationX,locationY)

class Health():
    def __init__(self,display,x=5,y=15):
        self.display = display
        self.Dinfo = pygame.display.Info()
        self.y = y
        if x==5:
            self.x = int(self.Dinfo.current_w * 0.8)
        else:
            self.x = x
        self.reset_health()

    def reset_health(self):
        self.health = []
        width = int(self.Dinfo.current_w/20)
        height = int(self.Dinfo.current_h/20)
        for i in range(3):
            self.health.append(Life(self.display,width,height,self.x+(i*width)+i,self.y))

    def loose_health(self):
        if len(self.health) > 1:
            del self.health[len(self.health)-1]
            return True
        else:
            return False

    def show(self):
        for life in self.health:
            life.show()
            
            
            
class Road(Paths):
    def __init__(self,display,locationY,Player,path_height):
        super().__init__(display,locationY,Player,path_height)
        
    def build(self):
        num = random.randint(1,2)
        for i in range(num):
            path = Car_path(self.display,0, self.Dinfo.current_w / int(self.Dinfo.current_w/random.randint(3,5)),self.path_height)
            path.y = self.y + (i * path.height) 
            path.add_objects()
            self.paths.append(path)
            
            
class Player(Game_object):
    def __init__(self,display,path_height):
        self.Dinfo = pygame.display.Info()
        self.path_height = path_height
        self.Hspeed = int(self.path_height/2)
        self.Vspeed = self.path_height
        self.width = self.path_height-10
        self.height = self.path_height-10
        self.start_y = self.starting_y()       
        self.reset()
        super().__init__(display,"micho.png",self.width,self.height,self.x,self.y)
        self.r_image = pygame.transform.scale(self.image,(self.width, self.height))
        self.u_image = self.image
        

    def movement(self,event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT and self.x < (self.Dinfo.current_w - self.width):

                self.image = self.r_image
                self.x += self.Hspeed
                
            elif event.key == pygame.K_LEFT and self.x > 0:
    
                self.image=pygame.image.load("michoL.png")
                self.image= pygame.transform.scale(self.image,(self.width, self.height))
        
                self.x -= self.Hspeed
                
            elif event.key == pygame.K_UP:
               
                self.image = self.u_image
                self.y -= self.Vspeed
                
            elif event.key == pygame.K_DOWN and self.y < self.start_y:
                
                self.image=pygame.image.load("michoL.png")
                self.image= pygame.transform.scale(self.image,(self.width, self.height))
                
                self.y += self.Vspeed

    def reset(self):
        self.y = self.start_y
        self.x = int((self.Dinfo.current_w - self.width)/2)

    def starting_y(self):
        ah = self.Dinfo.current_h -(self.Dinfo.current_h % self.path_height)
        return (ah - self.path_height) + int((self.path_height-self.height)/2)

    def player_won(self):
        return self.y < self.path_height     

class Level():
    def __init__(self,display,Player,path_height):
        self.display = display
        self.Dinfo = pygame.display.Info()
        self.y = 0
        self.height = 0
        self.player = Player
        self.paths = []
        self.path_height = path_height
        self.build(display)
        

    def build(self,display):
        path = ""
        while self.height + self.path_height < self.Dinfo.current_h:
            
            path = Road(display,self.path_height+self.height,self.player,self.path_height)

            if self.height + path.height + self.path_height < self.Dinfo.current_h:
                self.paths.append(path)
                self.height = path.y + path.height
            else:
                break

    def failed(self,Player):
        for path in self.paths:
            if path.failed(self.player):
                return True
        return False
    
    def show(self):
        for path in self.paths:
            path.show()

    def traffic(self,Player):
        for path in self.paths:
            path.traffic(Player)
            
class michoGame():
    def __init__(self,displaywidth,displayheight):
        
        self.width=displaywidth
        self.height=displayheight
        self.path_height = int(self.height/10)
        self.screen=pygame.display.set_mode((self.width,self.height))
        bgimage = pygame.image.load("pasto.jpg").convert()
        self.backgroundImage = pygame.transform.scale(bgimage, (self.width,self.height))
        self.lost_image = pygame.image.load("wasted.jpg")
        self.player = Player(self.screen,self.path_height)
        self.level = Level(self.screen,self.player,self.path_height)
        self.health = Health(self.screen)
        

    def event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            self.player.movement(event)

    def clean_events(self):
        for event in pygame.event.get():
            pass

    def completed_level(self,Player):
        if Player.y <= 0:
            return True
        return False

    def show(self):
        self.screen.blit(self.backgroundImage,(0,0))
        self.level.show()
        self.player.show()
        self.health.show()
        
        pygame.display.update()


    def reset_game(self):
        self.screen.blit(self.lost_image,(0,0))
        pygame.display.update()
       
        wait = True
        while wait:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    self.health.reset_health()
                    self.player.reset()
                    self.level = Level(self.screen,self.player, self.path_height)
                    self.player.image = self.player.u_image
                    wait = False

    def run(self, clock):
        while True:
            self.event()
            self.show()
            self.level.traffic(self.player)
            if self.level.failed(self.player):
                if not self.health.loose_health():
                    self.reset_game()
                else:
                    clock.tick(5)
                    self.player.reset()
                    self.level = Level(self.screen,self.player, self.path_height)
                    self.clean_events()
                    self.player.image = self.player.u_image
             
            if self.player.player_won():
                nivcompletos=1
                break
            
                
       

def niv1(screen):
    clock = time.Clock()
    game = michoGame(800,600)
    game.run(clock)
    
    screen.blit(pygame.image.load("winLevel1.jpg"), (0,0))
    screen.blit(casitaniv2, (750,15))
    
    display.flip()
    wait=True
    while wait==True:
        for e in event.get():
            if e.type == MOUSEBUTTONDOWN and e.button==1:
                if menunivel2.collidepoint(mouse.get_pos()):
                    print("clic")
                    wait=False
                    return 1
            key = pygame.key.get_pressed()
            if key[pygame.K_SPACE]:
                wait=False
                return 3



#score niv 2
score2 = 0


#perdiste nivel 2
font_small = pygame.font.SysFont('Lucida Sans', 30)
font_big = pygame.font.SysFont('Lucida Sans', 56)

#function for outputting text onto the screen
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x,y))
    
#función para dibujar el panel de información
def draw_panel():
    draw_text('SCORE: ' + str(score2) + '/1500', font_small, (0,0,0), 10, 15)

# game variables nivel 2
SCROLL_THRESH = 200
GRAVITY = 1
MAX_PLATFORMS=10
scroll=0
game_over = False



def historia(screen):
    clock = time.Clock()
    while True:
        for e in event.get():
            if e.type == QUIT: sys.exit()
            if e.type == MOUSEBUTTONDOWN and e.button==1:
                if continuarbut.collidepoint(mouse.get_pos()):
                    print("clic")
                    return 1
        inicio = image.load('fondoInicio.jpg')
        inicio = transform.scale(inicio, (800,600))
        inicioBoton= image.load('startButton.png')
        draw.rect(screen, (0,0,0), continuarbut, 3)
        inicioBoton= transform.scale(inicioBoton,(200,90))
        screen.blit(inicio, (0,0))
        screen.blit(inicioBoton, (290,450))
        
        
        display.flip()
        clock.tick(60)

def menu(screen):
    clock = time.Clock()
    while True:
        fondoMenu=image.load("fondoMenu.jpg")
        screen.blit(fondoMenu, (0,0))

        global nivcompletos
        for e in event.get():
            if e.type == QUIT: sys.exit()
            if e.type == MOUSEBUTTONDOWN and e.button==1:
                if clicniv1.collidepoint(mouse.get_pos()):
                    if nivcompletos == 0:
                        print("clic")
                        return 2
                elif clicniv2.collidepoint(mouse.get_pos()):
                    if nivcompletos == 1:
                        print("clic")
                        return 3
                elif clicniv3.collidepoint(mouse.get_pos()):
                    if nivcompletos == 2:
                        print("clic")
                        return 4
                    
        # Si nivel 1 está bloqueado
        if nivcompletos >= 0:            
            if clicniv1.collidepoint(mouse.get_pos()):
                draw.rect(screen, (254,247,23), clicniv1, 0)
            else:
                draw.rect(screen, (102,178,106), clicniv1, 0)
        else:
            draw.rect(screen, (155,155,155), clicniv1, 0)
            
        # Si nivel 2 está bloqueado
        if nivcompletos >= 1:
            if clicniv2.collidepoint(mouse.get_pos()):
                draw.rect(screen, (254,247,23), clicniv2, 0)
            else:
                draw.rect(screen, (102,178,106), clicniv2, 0)
        else:
            draw.rect(screen, (155,155,155), clicniv2, 0)
            
        # si nivel 3 está bloqueado
        if nivcompletos >= 2:
            if clicniv3.collidepoint(mouse.get_pos()):
                draw.rect(screen, (254,247,23), clicniv3, 0)
            else:
                draw.rect(screen, (102,178,106), clicniv3, 0)
        else:
            draw.rect(screen, (155,155,155), clicniv3, 0)
            
        draw.rect(screen, (0,0,0), clicniv1, 3)
        draw.rect(screen, (0,0,0), clicniv2, 3)
        draw.rect(screen, (0,0,0), clicniv3, 3)
        
        if nivcompletos == 0:
            nivel1 = myFont.render("Nivel 1", True, (0,0,0))
        if nivcompletos >= 1:
            nivel1 = myFont.render("Hecho", True, (0,0,0))
        if nivcompletos <=1:
            nivel2 = myFont.render("Nivel 2", True, (0,0,0))
        if nivcompletos >1:
            nivel2 = myFont.render("Hecho", True, (0,0,0))
        if nivcompletos <=2:
            nivel3 = myFont.render("Nivel 3", True, (0,0,0))
        
        screen.blit(nivel1, (340,302))
        screen.blit(nivel2, (340,402))
        screen.blit(nivel3, (340,502))
        display.flip()
        

# a partir de aquí son las clases que serán usadas para el nivel 2       
class player():
    def __init__(self,x,y):
        self.image = michoniv2
        self.width = 25
        self.height = 40
        self.rect = Rect(0, 0, self.width, self.height)
        self.rect.center = (x,y)
        self.vel_y = 0
        self.flip = False
        
    def move(self):
        scroll=0
        dx = 0
        dy = 0
        
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            dx = -10
            self.flip = False
        if key[pygame.K_RIGHT]:
            dx = 10
            self.flip = True
            
        self.vel_y += GRAVITY
        dy += self.vel_y
            
        if self.rect.left + dx < 0:
            dx = 0 - self.rect.left
            
        if self.rect.right + dx > 800:
            dx = 800 - self.rect.right
            
            
        #checar colisión con las plataformas
        for platform in platform_group:
            #colisión en la dirección y
            if platform.rect.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                if self.rect.bottom < platform.rect.centery:
                   if self.vel_y > 0:
                       self.rect.bottom = platform.rect.top
                       dy = 0
                       self.vel_y = -23.5
            
            
        #check collision with ground
        
            
        #ver si el jugador ha llegado a la cima de la pantalla
        if self.rect.top <= SCROLL_THRESH:
            #si el jugador está saltando
            if self.vel_y <0:
                scroll = -dy
            
            
        self.rect.x += dx
        self.rect.y += dy + scroll
        
        return scroll
        
    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False),(self.rect.x - 15, self.rect.y - 4))
        
        
        
class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(platform_image, (width, 10))
        self.rect = self.image.get_rect()
        self.rect.x=x
        self.rect.y=y
        
    def update(self, scroll):
        
        #update platform's practical position
        self.rect.y += scroll
        
        # checar si platform se ha salido de la pantalla
        if self.rect.top > 800:
            self.kill()
        
        
michoniv2 = player(400,450)

platform_group=pygame.sprite.Group()

#create starting platform
platform = Platform(350, 550, 100)
platform_group.add(platform)
        
def niv2(screen):
    clock = time.Clock()
    while True:
        global platform
        global score2
        global game_over
        global nivcompletos
        for e in event.get():
            if e.type == QUIT: sys.exit()
            if e.type == MOUSEBUTTONDOWN and e.button==1:
                if menunivel2.collidepoint(mouse.get_pos()):
                    print("clic")
                    return 1
        
        if game_over == False:
         
            scroll = michoniv2.move()
            screen.blit(niv2background, (0,0))
            screen.blit(casitaniv2, (750,15))
            
            
            #generar plataformas
            if len(platform_group) < MAX_PLATFORMS:
                p_w = random.randint(60,80)
                p_x = random.randint(50, 750-p_w)
                p_y = platform.rect.y - random.randint(80,110)
                platform = Platform(p_x, p_y, p_w)
                platform_group.add(platform)
            
            platform_group.update(scroll)
            
            #update score
            if scroll>0:
                score2 += scroll//2
            
            platform_group.draw(screen)
            
            #check game over
            if michoniv2.rect.top > 800:
                game_over = True
            
        else:
            if score2 < 1500:
                screen.blit(pygame.image.load("wasted.jpg"),(0,0))
                pygame.display.update()
                key = pygame.key.get_pressed()
                if key[pygame.K_SPACE]:
                    #resetear variables
                    game_over = False
                    score2 = 0
                    scroll = 0
                    #reposition player
                    michoniv2.rect.center = (400,450)
                    #reset platforms
                    platform_group.empty()
                    #crear plataforma de inicio
                    platform = Platform(350, 550, 100)
                    platform_group.add(platform)
            else:
                screen.blit(pygame.image.load("winLevel2.jpg"),(0,0))
                pygame.display.update()
                key = pygame.key.get_pressed()
                nivcompletos = 2
                if key[pygame.K_SPACE]:
                    game_over=False
                    return 1
        if score2 >= 1500:
            game_over = True
            
        if game_over == False:
            michoniv2.draw()
            draw_panel()
            display.flip()
            clock.tick(60)
        
        


        
def niv3pt1(screen):
    clock = time.Clock()
    while True:
        for e in event.get():
            if e.type == QUIT: sys.exit()
            if e.type == MOUSEBUTTONDOWN and e.button==1:
                if menunivel2.collidepoint(mouse.get_pos()):
                    print("clic")
                    return 1
                if continuarbut2.collidepoint(mouse.get_pos()):
                    print("clic")
                    return 5
        continuar = myFont.render("Continuar", True, (0,0,0))   
        niv3pt1 = image.load('niv3pt1.png')
        niv3pt1 = transform.scale(niv3pt1, (800,600))
        screen.blit(niv3pt1, (0,0))
        screen.blit(casitaniv2, (750,15))
        
        inicioBoton= image.load('startButton.png')
        inicioBoton= transform.scale(inicioBoton,(200,90))
        draw.rect(screen, (0,0,0), continuarbut2, 3)
        screen.blit(inicioBoton, (510,480))
    
        
        
        display.flip()
        clock.tick(60)
        
def niv3pt2(screen):
    clock = time.Clock()
    while True:
        for e in event.get():
            if e.type == QUIT: sys.exit()
            if e.type == MOUSEBUTTONDOWN and e.button==1:
                if menunivel2.collidepoint(mouse.get_pos()):
                    print("clic")
                    return 1
                if casa.collidepoint(mouse.get_pos()):
                    print("clic")
                    return 6
       
        niv3pt2 = image.load('vecindad.png')
        niv3pt2 = transform.scale(niv3pt2, (800,600))
        screen.blit(niv3pt2, (0,0))
        screen.blit(casitaniv2, (750,15))
        casa = Rect(0,230, 150,150)
        draw.rect(screen, (255,255,255), (160, 50, 475, 70))
        draw.rect(screen, (0,0,0), (160, 50, 475, 70), 3)
        instrucciones = image.load('instrucciones.png')
        instrucciones = transform.scale(instrucciones, (800,600))
        screen.blit(instrucciones, (0,0))
        
        
        display.flip()
        clock.tick(60)
        
def final(screen):
    clock = time.Clock()
    while True:
        for e in event.get():
            if e.type == QUIT: sys.exit()
        
        pfinal = image.load('final.jpg')
        pfinal = transform.scale(pfinal, (800,600))
        screen.blit(pfinal, (0,0))
        
        display.flip()
        clock.tick(60)

escena = 0


while True:
    if escena==0:
        escena = historia(screen)
    if escena==1:
        escena = menu(screen)
    elif escena==2:
        escena = niv1(screen)
    elif escena==3:
        escena = niv2(screen)
    elif escena==4:
        escena = niv3pt1(screen)
    elif escena==5:
        escena = niv3pt2(screen)
    elif escena==6:
        escena = final(screen)